# Trivia Game Coding - Test Assignment

## How to run the application

- Run `yarn` in the root directory to download all dependencies of all workspaces
- Run `yarn start` in the root directory to run the application locally